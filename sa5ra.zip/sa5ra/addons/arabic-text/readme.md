# godot-arabic-text

A godot plugin for correctly displaying Arabic text. Currently in Alpha. May work for other RTL languages

## Credits
- [cpython](https://github.com/python/cpython)
- [python-arabic-reshaper](https://github.com/mpcabd/python-arabic-reshaper)
